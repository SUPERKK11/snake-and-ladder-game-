import tkinter as tk
from tkinter import Canvas, Button, Label
from PIL import Image, ImageTk
import random


class SnakeAndLadderGame:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Snake and Ladder Game")

        self.canvas = Canvas(self.root, width=400, height=400)
        self.canvas.pack()

        # Load and resize the background image
        self.background_image = Image.open("img.png")
        self.background_image = self.background_image.resize((400, 400), Image.BILINEAR)
        self.background_image = ImageTk.PhotoImage(self.background_image)

        # Add the background image to the canvas
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.background_image)

        self.board = self.create_board()
        self.player_position = 0
        self.player_token = None

        self.draw_board()

        self.roll_button = Button(self.root, text="Roll Dice", command=self.roll_dice)
        self.roll_button.pack()

        self.dice_result_label = Label(self.root, text="")
        self.dice_result_label.pack()

    def create_board(self):
        board = {}
        for i in range(1, 101):
            board[i] = i
        # Define snakes and ladders
        snakes_and_ladders = {
            16: 6,
            47: 26,
            49: 11,
            56: 53,
            62: 19,
            64: 60,
            87: 24,
            93: 73,
            95: 75,
            98: 78
        }
        # Update board with snakes and ladders
        for start, end in snakes_and_ladders.items():
            board[start] = end
        return board

    def draw_board(self):
        for i in range(1, 101):
            row, col = self.get_row_col(i)
            x = (col - 1) * 40
            y = (10 - row) * 40
            self.canvas.create_rectangle(x, y, x + 40, y + 40, outline="black")
            self.canvas.create_text(x + 20, y + 20, text=str(i))

    def get_row_col(self, position):
        row = (position - 1) // 10 + 1
        col = (position - 1) % 10 + 1
        if row % 2 == 0:
            col = 11 - col
        return row, col

    def roll_dice(self):
        dice_roll = random.randint(1, 6)
        self.player_position += dice_roll
        if self.player_position > 100:
            self.player_position = 100 - (self.player_position - 100)
        self.player_position = self.board.get(self.player_position, self.player_position)

        # Update the canvas to show player's movement
        self.update_player_token()

        # Show the dice number
        self.dice_result_label.config(text=f"Dice roll: {dice_roll}")

        if self.player_position == 100:
            self.roll_button.config(state="disabled")
            print("Congratulations! You win!")

    def update_player_token(self):
        row, col = self.get_row_col(self.player_position)
        x = (col - 1) * 40 + 20
        y = (10 - row) * 40 + 20
        if self.player_token:
            self.canvas.delete(self.player_token)
        self.player_token = self.canvas.create_oval(x - 10, y - 10, x + 10, y + 10, fill="blue")

    def run(self):
        self.root.mainloop()


game = SnakeAndLadderGame()
game.run()












