import tkinter as tk
from tkinter import Canvas, Button, Label, OptionMenu, Toplevel
from PIL import Image, ImageTk
import random


class SnakeAndLadderGame:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Snake and Ladder Game")

        self.start_window = tk.Toplevel(self.root)
        self.start_window.title("Snake and Ladder Game")

        self.start_canvas = Canvas(self.start_window, width=400, height=400)
        self.start_canvas.pack()

        self.start_button = Button(self.start_window, text="Start", command=self.start_game)
        self.start_button.pack()

        # Load and resize the background image for the main game screen
        self.background_image = Image.open("img.png")
        self.background_image = self.background_image.resize((400, 400), Image.BILINEAR)
        self.background_image = ImageTk.PhotoImage(self.background_image)

        self.board = self.create_board()
        self.player_count = 0
        self.current_player = 1
        self.player_positions = {}
        self.player_tokens = {}

        self.dice_result_label = None

    def start_game(self):
        self.start_window.withdraw()  # Hide the start window
        self.root.deiconify()  # Show the main game window

        self.canvas = Canvas(self.root, width=400, height=400)
        self.canvas.pack()

        # Add the background image to the canvas
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.background_image)

        self.draw_board()

        self.player_count_label = Label(self.root, text="Select number of players:")
        self.player_count_label.pack()

        self.player_count_var = tk.StringVar(self.root)
        self.player_count_var.set("2")  # Default value
        self.player_count_menu = OptionMenu(self.root, self.player_count_var, "2", "3", "4", command=self.update_player_count)
        self.player_count_menu.pack()

        self.roll_button = Button(self.root, text="Roll Dice", command=self.roll_dice)
        self.roll_button.pack()

        self.dice_result_label = Label(self.root, text="")
        self.dice_result_label.pack()

    def create_board(self):
        board = {}
        for i in range(1, 101):
            board[i] = i
        # Define snakes and ladders
        snakes_and_ladders = {
            1:38, 4: 14, 8:20, 21: 42, 28: 76, 32:9, 26: 48, 67: 50, 92: 71, 99: 80,
            97: 78, 95: 56, 88: 24, 48: 26, 32: 10, 62: 18,  50: 67, 71: 92, 80: 99
        }
        # Update board with snakes and ladders
        for start, end in snakes_and_ladders.items():
            board[start] = end
        return board

    def draw_board(self):
        for i in range(1, 101):
            row, col = self.get_row_col(i)
            x = (col - 1) * 40
            y = (10 - row) * 40
            self.canvas.create_rectangle(x, y, x + 40, y + 40, outline="black")
            self.canvas.create_text(x + 20, y + 20, text=str(i))

    def get_row_col(self, position):
        row = (position - 1) // 10 + 1
        col = (position - 1) % 10 + 1
        if row % 2 == 0:
            col = 11 - col
        return row, col

    def update_player_count(self, *args):
        self.player_count = int(self.player_count_var.get())
        self.reset_players()

    def reset_players(self):
        # Remove existing player tokens from the canvas
        if hasattr(self, "player_tokens"):
            for token in self.player_tokens.values():
                self.canvas.delete(token)

        # Reset player positions and assign unique colors
        self.player_positions = {i: 1 for i in range(1, self.player_count + 1)}
        self.player_tokens = {}
        colors = ["red", "blue", "green", "orange"]  # Add more colors if needed
        for i in range(1, self.player_count + 1):
            x, y = self.get_row_col(1)
            x = (y - 1) * 40 + 20
            y = (10 - x) * 40 + 20
            self.player_tokens[i] = self.canvas.create_oval(x - 10, y - 10, x + 10, y + 10, fill=colors[i - 1])

    def roll_dice(self):
        dice_roll = random.randint(1, 6)
        self.player_positions[self.current_player] += dice_roll
        if self.player_positions[self.current_player] > 100:
            self.player_positions[self.current_player] = 100 - (self.player_positions[self.current_player] - 100)
        self.player_positions[self.current_player] = self.board.get(
            self.player_positions[self.current_player], self.player_positions[self.current_player])

        # Update the player token position on the canvas
        self.update_player_position(self.current_player)

        # Show the dice number
        self.dice_result_label.config(text=f"Player {self.current_player}: Dice roll - {dice_roll}")

        if self.player_positions[self.current_player] == 100:
            self.roll_button.config(state="disabled")
            messagebox.showinfo("Congratulations!", f"Player {self.current_player} wins!")

        self.current_player = self.get_next_player()

    def update_player_position(self, player):
        position = self.player_positions[player]
        if position in self.board:
            position = self.board[position]  # Move according to snake or ladder
        row, col = self.get_row_col(position)
        x = (col - 1) * 40 + 20
        y = (10 - row) * 40 + 20
        self.canvas.coords(self.player_tokens[player], x - 10, y - 10, x + 10, y + 10)

    def get_next_player(self):
        return 1 if self.current_player == self.player_count else self.current_player + 1

    def run(self):
        self.root.withdraw()  # Hide the main game window
        self.start_window.mainloop()


game = SnakeAndLadderGame()
game.run()







